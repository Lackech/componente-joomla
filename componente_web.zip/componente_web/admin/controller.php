<?php
/**
 * @package     Joomla.Administrator
 * 
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * General Controller of web component
 *
 * @package     Joomla.Administrator
 * @
 * @since       0.0.7
 */
class webController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'webs';
}
