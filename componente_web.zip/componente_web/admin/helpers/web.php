<?php
/**
 * @package     Joomla.Administrator
 * 
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorld component helper.
 *
 * @param   string  $submenu  The name of the active view.
 *
 * @return  void
 *
 * @since   1.6
 */
abstract class webHelper
{
	/**
	 * Configure the Linkbar.
	 */
	public static function addSubmenu($submenu) 
	{
		JSubMenuHelper::addEntry(
			JText::_('COM_WEB_SUBMENU_MESSAGES'),
			'index.php?option=com_web',
			$submenu == 'messages'
		);

		JSubMenuHelper::addEntry(
			JText::_('COM_WEB_SUBMENU_CATEGORIES'),
			'index.php?option=com_categories&view=categories&extension=com_web',
			$submenu == 'categories'
		);

		// set some global property
		$document = JFactory::getDocument();
		
		if ($submenu == 'categories') 
		{
			$document->setTitle(JText::_('COM_WEB_ADMINISTRATION_CATEGORIES'));
		}
	}
}
