<?php
/**
 * @package     Joomla.Administrator
 * 
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Web Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_web
 * @since       0.0.9
 */
class webControllerweb extends JControllerForm
{
}
