<?php
/**
 * @package     Joomla.Administrator
 * 
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Web Component Controller
 *
 * @since  0.0.1
 */
class webController extends JControllerLegacy
{
}
