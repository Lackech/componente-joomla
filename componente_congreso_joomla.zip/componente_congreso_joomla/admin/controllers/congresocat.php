<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_congreso
 *
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Category Controller
 *

 */
class congresoControllercongresocat extends JControllerForm
{

	protected $default_view = 'congresocats';
}