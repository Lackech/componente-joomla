DROP TABLE IF EXISTS `#__congreso`;
DROP TABLE IF EXISTS `#__congreso_category`;
DROP TABLE IF EXISTS `#__congreso_keywords`;